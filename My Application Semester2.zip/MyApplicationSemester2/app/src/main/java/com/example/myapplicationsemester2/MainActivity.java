package com.example.myapplicationsemester2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    ListView listViewData;
    ArrayAdapter<String> adapter;
    ArrayList arrayContent = new ArrayList<String>();
    //String arrayContent[] = {"Android", "React", "native", "Java"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listViewData = findViewById(R.id.listviewData);
        readItems();
        //adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice,arrayContent);

    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId() == R.id.item_done){
            String itemSelected = "Selected Items: \n";
            for(int i=0; i < listViewData.getCount();i++){
                try {
                    CheckBox cb = listViewData.getChildAt(i).findViewById(R.id.checkBox);
                    if(cb.isChecked())
                    {
                        itemSelected += listViewData.getItemAtPosition(i)+" ";
                    }
                }catch (Exception e) {

                }
            }
            Toast.makeText(this, itemSelected, Toast.LENGTH_SHORT).show();
        }
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("items");

        if(item.getItemId() == R.id.item_delete) {
            for(int i=0;i<listViewData.getCount();i++) {
                try {
                    CheckBox cb = listViewData.getChildAt(i).findViewById(R.id.checkBox);
                    if (cb.isChecked()) {
                        myRef.child(listViewData.getItemAtPosition(i) + "").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(getBaseContext(), "Item/s removed", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }catch(Exception e) {

                }
                }
            }
        return super.onOptionsItemSelected(item);
    }

    public void addItem(View view)
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("items");

        EditText et_item = findViewById(R.id.et_item);
        String item = et_item.getText().toString().trim();

        myRef.child(item).setValue(item).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    et_item.setText("");
                }
            }
        });
    }

    public void readItems()
    {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("items");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                arrayContent.clear();
                for(DataSnapshot itemSnapShot: snapshot.getChildren()){
                    arrayContent.add((itemSnapShot.getValue().toString()));
                }
                adapter = new CustomAdapter(getBaseContext(), arrayContent);
                listViewData.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                System.out.println("cancel");
            }
        });
    }


}